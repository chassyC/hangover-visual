# HANGOVER — Fuori / Campus

Sei nuove composizioni 4:5 (1080 × 1350), con PNG e SVG autonomi. Le due locandine originali del sito sono conservate. Fotografie dalla raccolta utente H-FARM RAG del 15 settembre 2026: persone, luoghi e colori fotografici non sono stati rigenerati. I JPEG sorgenti sono incorporati integralmente negli SVG; il layout applica soltanto riquadri e maschere vettoriali. Contorni HANGOVER approvati riusati senza modifiche. Testi di servizio Arial/Helvetica e Courier New del sistema.

Autori e diritti dei singoli scatti non verificati; provenienza e hash in manifest.json. Sono studi di direzione visiva: non annunciano eventi, partnership, programmi o date approvati. Le foto documentano momenti precedenti. Risoluzione fotografica originale 768 × 1024 o 1440 × 1800: il PNG 1080 × 1350 non aggiunge dettaglio ai file piccoli. Stampa e uso finale da verificare.
