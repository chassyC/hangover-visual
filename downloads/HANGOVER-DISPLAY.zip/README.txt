HANGOVER DISPLAY — 1.000

Font display unicase: le minuscole digitano le stesse forme delle maiuscole.
26 lettere inglesi, 10 numeri, punteggiatura, simboli e accenti italiani.
H A N G O V E R conservano i tracciati del wordmark di progetto.
Le altre forme sono un'estensione disegnata per questa identità, da questo lavoro.
Nessun carattere Arial/Courier è stato copiato o incluso nei file font.

TTF / OTF: installabili e utilizzabili nelle applicazioni compatibili.
WOFF2: versione per il sito, già collegata tramite CSS.
Sorgenti e provenienza: IDENTITA-VISIVA/source/font/.
Originali visuali e reference restano nel loro archivio.
Uso previsto: progetto HANGOVER. Nessuna licenza aperta implicita sulle reference.
