# HANGOVER — Objects Studio

60 oggetti e template. Apri APRI-OBJECTS-STUDIO.html nel browser: funziona anche senza connessione. Tocca un oggetto, scegli la palette, modifica titolo, data/luogo e link nei modelli per eventi; scarica SVG o PNG. La cartella SVG contiene le 60 versioni iniziali. Object Maker crea nuovi oggetti con testi, sagome, colori, effetti e QR personalizzati. Salva e riapri il progetto JSON; gli SVG usano i tracciati originali HANGOVER. Lo studio QR funziona localmente senza servizi a pagamento; il sito di destinazione deve restare disponibile.

I QR iniziali aprono https://chassyc.github.io/hangover-visual/ : sono esempi. Sostituisci il link con la destinazione del tuo evento. Non sono titoli di accesso univoci e non convalidano ingressi. Nessun servizio di tracciamento. URL http/https fino a 240 caratteri. Testa la scansione nella dimensione e sul supporto reali prima della stampa.

Formati nominali in mm negli SVG degli stampati. I capi sono mockup vettoriali di concept, non cartamodelli; il lanyard mostra il nastro disteso. Il PNG ha lato maggiore 2400 px ed è un'anteprima RGB. I contorni H/HG/HGR/HANGOVER sono quelli originali approvati. I testi di servizio usano Arial/Helvetica e monospace del sistema. Le foto riprendono i concept forniti e non vanno presentate come documentazione di un evento reale. Nessuna data, venue o tariffa approvata.

Prima della produzione: concordare abbondanze, profilo colore, materiali, sagoma/fustella, minimi di stampa/ricamo e prove colore con il fornitore.

QR: qrcode-generator di Kazuhiko Arase (MIT; licenza inclusa). https://github.com/kazuhikoarase/qrcode-generator — margine bianco di 4 moduli, nero su bianco, correzione M. Fonte: https://www.qrcode.com/en/howto/code.html
