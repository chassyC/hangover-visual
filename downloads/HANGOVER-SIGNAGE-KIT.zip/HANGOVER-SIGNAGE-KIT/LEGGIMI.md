# HANGOVER — Segui il segno

12 studi di segnaletica: le due insegne Night H/HG e dieci nuove composizioni. Apri APRI-SEGNALI.html nel browser, anche senza connessione. Scegli composizione, mood/colore, testo (massimo 22 caratteri) e direzione. Mescola cambia palette e freccia; Ripristina torna al preset originale. Ogni studio si esporta in SVG o PNG con lato maggiore 2400 px. I 12 SVG iniziali sono nella cartella SVG.

Le forme H/HG/HGR/HANGOVER riusano esattamente le matrici approvate. I testi di servizio usano Arial/Helvetica e Courier New del sistema. Nessuna immagine esterna, font scaricato o servizio remoto. Palette e trattamenti sono proposte grafiche per i diversi mood musicali, non identità approvate di eventi specifici.

Dimensioni indicative in mm. Insegne luminose e metallo sono simulazioni grafiche. Materiali, sagome, colori, finiture, installazione e leggibilità nel luogo reale richiedono una prova con il fornitore. Questo kit riguarda orientamento e branding del locale; non sostituisce la segnaletica di sicurezza. Le tre destinazioni del totem Stack sono una composizione dimostrativa: il campo Dove si va modifica la destinazione principale.
